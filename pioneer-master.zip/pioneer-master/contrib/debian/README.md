
Debian
====================
This directory contains files used to package Pioneerd/Pioneer-qt
for Debian-based Linux systems. If you compile Pioneerd/Pioneer-qt yourself, there are some useful files here.

## Pioneer: URI support ##


Pioneer-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install Pioneer-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your Pioneer-qt binary to `/usr/bin`
and the `../../share/pixmaps/Pioneer128.png` to `/usr/share/pixmaps`

Pioneer-qt.protocol (KDE)

