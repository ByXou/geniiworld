Sample configuration files for:
```
SystemD: Pioneerd.service
Upstart: Pioneerd.conf
OpenRC:  Pioneerd.openrc
         Pioneerd.openrcconf
CentOS:  Pioneerd.init
OS X:    org.Pioneer.Pioneerd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
